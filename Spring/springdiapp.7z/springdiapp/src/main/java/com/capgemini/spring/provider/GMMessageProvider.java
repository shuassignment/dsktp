package com.capgemini.spring.provider;

public class GMMessageProvider implements MessageProvider {

	public String getMessage() {
		// TODO Auto-generated method stub
		return "Good Morning!";
	}

}
