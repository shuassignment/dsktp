package com.capgemini.spring.provider;

public class HWMessageProvider implements MessageProvider {

	public String getMessage() {
		// TODO Auto-generated method stub
		return "Hello World!";
	}

}
