package com.capgemini.spring.provider;

public interface MessageProvider {
	public String getMessage();
}
