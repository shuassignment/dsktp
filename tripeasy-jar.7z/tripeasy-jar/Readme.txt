
Trip Easy 
create database "tripeasy"


1. create new profile  (after 
creating profile, it will automatically login)
2.Use the services i.e Flight booking & Hotel Booking Services 
